import Vue from 'vue'
import VueRouter from 'vue-router'

// 导入页面
import Main from '@/views/Main'
import ShowArticle from '@/views/blogFront/ShowArticle'
import MainArticleList from '@/views/blogFront/MainArticleList'
import BackMain from '@/views/blogBack/BackMain'
import BackNewArticle from '@/views/blogBack/BackNewArticle'
import BackModifyArticle from '@/views/blogBack/BackModifyArticle'
import BackLogin from '@/views/blogBack/BackLogin'

Vue.use(VueRouter)

const routes = [
  // ---------- 此处为前台相关的路由 ----------
  // 首页
  {
    path: '/',
    component: Main,
    redirect: '/articleList',
    children: [
      // 子页面：文章列表
      { path: '/articleList', component: MainArticleList },
      // 子页面：文章查看
      { path: '/ShowArticle/:arid', component: ShowArticle }
    ]
  },

  // ---------- 此处为后台相关的路由 ----------
  // 后台主页
  { path: '/backMain', component: BackMain },
  // 新增文章页面
  { path: '/backNewArticle', component: BackNewArticle },
  // 修改这篇文章
  { path: '/backModifyArticle/:ar_id', component: BackModifyArticle },
  // 补上登录界面
  { path: '/back', component: BackLogin }
]

const router = new VueRouter({
  routes
})

router.beforeEach((to, form, next) => {
  if (to.path === '/') return next()
  if (to.path === '/articleList') return next()
  if (to.path === '/back') return next()
  if (to.path.search('/ShowArticle') !== -1) return next()

  const tokenStr = window.sessionStorage.getItem('token')
  if (!tokenStr) return next('/')
  next()
})

export default router
