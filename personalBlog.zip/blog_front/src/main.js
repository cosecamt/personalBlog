import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import './plugins/element.js'

// 富文本编辑器 vue-quill-editor
import QuillEditor from 'vue-quill-editor'
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.bubble.css'
import 'quill/dist/quill.snow.css'

// 全局CSS初始化
import './assets/css/globalCSS.css'
// 导入axios
import axios from 'axios'

Vue.config.productionTip = false

// 使用vue-quill-editor
Vue.use(QuillEditor)

// 导入axios
axios.defaults.baseURL = process.env.VUE_APP_API_URL
Vue.prototype.$axios = axios

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')


