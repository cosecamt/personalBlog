import Vue from 'vue'
import {
  Button, Container, Aside, Main, Header, Input, DatePicker, Select, Option, Card, CheckboxGroup,
  Checkbox, Link, Divider, Breadcrumb, BreadcrumbItem, Avatar, Pagination
} from 'element-ui'

Vue.use(Button)
Vue.use(Container)
Vue.use(Aside)
Vue.use(Main)
Vue.use(Header)
Vue.use(Input)
Vue.use(DatePicker)
Vue.use(Select)
Vue.use(Option)
Vue.use(Card)
Vue.use(Checkbox)
Vue.use(CheckboxGroup)
Vue.use(Link)
Vue.use(Divider)
Vue.use(Breadcrumb)
Vue.use(BreadcrumbItem)
Vue.use(Avatar)
Vue.use(Pagination)
