<template>
  <div>
    <el-card shadow="never" style="width: 1000px;margin: auto;">
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>{{articleList.ar_id}}</el-breadcrumb-item>
      </el-breadcrumb>
      <!--标题部分-->
      <span class="TitleBox">{{articleList.ar_title}}</span>
      <!--文章类型-->
      <span class="DateBox">文章类型：{{articleList.ar_category}}</span>
      <!--日期-->
      <span class="DateBox">发布时间：{{articleList.ar_showtime}}</span>
      <!--标签-->
      <span class="TagsBox">标签：{{splitTagString(articleList.ar_tags)}}</span>
      <el-divider></el-divider>
      <!--正文-->
      <div class="ql-container ql-snow">
        <div class="ql-editor" v-html="articleList.ar_content"></div>
      </div>
    </el-card>
    <!--待处理部分-->
  </div>
</template>

<script>
export default {
  data () {
    return {
      // 文章信息
      articleList: {
        ar_id: '',
        ar_title: '',
        ar_content: '',
        ar_author: '',
        ar_tags: '',
        ar_category: '',
        ar_showtime: ''
      }
    }
  },
  methods: {
    // 获取单篇文章信息，这次需要完整的信息，包括文章内容
    async getCompleteArticle () {
      // 先把id弄到
      const arid = this.$route.params.arid
      const { data: res } = await this.$axios.post('getCompleteArticle', { ar_id: arid })
      this.articleList = res
    },
    splitTagString (tagString) {
      if (tagString === '') {
        return
      }
      const listTags = tagString.split(';')
      listTags.pop()
      let newString = ''
      for (let i = 0; i < listTags.length; i++) {
        newString = newString + ' ' + listTags[i]
      }
      return newString
    }
  },
  mounted () {
    // 由于生命周期问题，将读取列表的工作稍微推迟一点
    this.$nextTick(function () {
      // 从后台把标签及其相关的数据拿出来
      this.getCompleteArticle()
    })
  }

}
</script>

<style lang="less" scoped>
//标题
.TitleBox{
  display: block;
  margin: 20px 0 20px 0;
  text-align: center;
  font-size: 26px;
  font-weight: 700;
}
//发布日期，文章类型也共用一下
.DateBox{
  margin-left: 100px;
}
//标签
.TagsBox{
  margin-left: 100px;
}
//把显示文章内容部分的边框去掉
.ql-container.ql-snow{
  border: 0;
  height: 100%;
}
</style>
