<template>
  <div>
    <!--置顶的搜索框-->
    <el-input placeholder="请输入搜索内容" v-model="searchKeyWord" class="searchBox">
      <el-button @click="cleanSearch" slot="append" icon="el-icon-delete"></el-button>
    </el-input>
    <el-card shadow="never" style="width: 1000px;margin: auto;">
      <!--类型选择-->
      <div @click="changeCategory(category.ar_category)" :class="setCategoryBox(category.ar_category)" v-for="(category,index) in categoryInfo" :key="index + category.ar_category">
        <div style="text-align: center;padding: 3px 3px;">
          {{category.ar_category}}
          <span class="TagCount">{{category.categoryCount}}</span>
        </div>
      </div>
      <el-divider></el-divider>
      <!--标签选择-->
      <div @click="changeTags(tag.ta_words)" :class="setTagBox(tag.ta_words)" v-for="(tag,index) in tagsInfo" :key="index + tag.ta_id">
        <div style="text-align: center;padding: 3px 3px;">
          {{tag.ta_words}}
          <span class="TagCount">{{tag.tagCount}}</span>
        </div>
      </div>
      <el-divider></el-divider>
      <!--文章列表-->
      <div class="ArticleBox" v-for="article in filterArticle(articleList, 'show')" :key="article.ar_id">
        <el-card @click.native="readArticle(article.ar_id)" class="ArticleCard" shadow="hover">
          <span class="CategoryText">{{article.ar_category}}</span>
          <span class="TitleText">{{article.ar_title}}</span><br>
          <!--标签挂件-->
          <div class="tagsBox" style="display: inline-block" v-for="tag in transformTagsList(article.ar_tags)" :key="tag">
            <span class="tagsTriangle"></span>
            <div class="tagsText">
              <i class="el-icon-collection-tag" style="margin-right: 5px"></i>
              <span>{{tag}}</span>
            </div>
          </div>
          <!--文章时间-->
          <span class="showtimeBox">发布时间：{{article.ar_showtime}}</span>
        </el-card>
      </div>
      <!--分页部分-->
      <el-pagination layout="prev, pager, next" :total="filterArticle(articleList, 'count').length" @current-change="changePagination"
                     :page-size="paginationSize" :current-page="paginationCurrent">
      </el-pagination>
    </el-card>
  </div>
</template>

<script>
export default {
  data () {
    return {
      // 标签数据
      // tagsInfo: [{ ta_id: '', ta_words: '', tagCount: 0 }],
      tagsInfo: [],
      // 类型数据
      // categoryInfo: [{ ar_category: '', categoryCount: 0 }]
      categoryInfo: [],
      // 文章信息
      articleList: [
        {
          ar_id: '',
          ar_title: '',
          ar_author: '',
          ar_tags: '',
          ar_category: '',
          ar_showtime: ''
        }],
      // articleList: [],
      // 把tag拆解成列表来使用
      tagsList: [],
      // 记录当前选中的标签
      nowTag: '',
      // 记录当前选中类型
      nowCategory: '',
      // 搜索关键字
      searchKeyWord: '',
      // 分页时，条目的总数
      paginationTotal: 1,
      // 当前页数
      paginationCurrent: 1,
      // 分页的每页数量，也许将来会改成可变的，所以做一个变量
      paginationSize: 10
    }
  },
  methods: {
    // 从后台把标签及其相关的数据拿出来
    async getTagsInfo () {
      const { data: res } = await this.$axios.post('getTagsInfo')
      this.tagsInfo = res
    },
    // 找到所有的文章类型，并且把数据拿出来
    async getCategoryInfo () {
      const { data: res } = await this.$axios.post('getCategoryInfo')
      this.categoryInfo = res
    },
    // 文章的信息取出来，内容不能取
    async getArticleInfo () {
      const { data: res } = await this.$axios.post('getArticleInfo')
      this.articleList = res
      // 把数组的长度赋予分页
      this.paginationTotal = res.length
    },
    // 把tag拆解成列表来使用
    transformTagsList (tagsText) {
      const listSplit = tagsText.split(';')
      listSplit.pop()
      return listSplit
    },
    // 阅读文章
    readArticle (id) {
      // this.$router.push('/ShowArticle/' + id)
      window.open(process.env.VUE_APP_PAGE_URL + 'ShowArticle/' + id, '_blank');
    },
    // 修改标签的样式
    setTagBox (tagWord) {
      if (this.nowTag === tagWord) {
        return 'TagBox TagBlue'
      }
      return 'TagBox'
    },
    // 修改当前选中的标签
    changeTags (tagWord) {
      // 先把分页返回1
      this.paginationCurrent = 1
      if (this.nowTag === tagWord) {
        this.nowTag = ''
      } else {
        this.nowTag = tagWord
      }
    },
    // 修改类型的样式
    setCategoryBox (category) {
      if (this.nowCategory === category) {
        return 'TagBox TagBlue'
      }
      return 'TagBox'
    },
    // 修改当前选中的类型
    changeCategory (category) {
      // 先把分页返回1
      this.paginationCurrent = 1
      if (this.nowCategory === category) {
        this.nowCategory = ''
      } else {
        this.nowCategory = category
      }
    },
    // 清空搜索栏
    cleanSearch () {
      this.searchKeyWord = ''
    },
    // 筛选文章列表
    filterArticle (articleList, type) {
      // 根据标签筛选
      articleList = articleList.filter((dataCheck) => {
        if (
          (dataCheck.ar_tags.search(this.nowTag) !== -1 || this.nowTag === '') &&
          (dataCheck.ar_category === this.nowCategory || this.nowCategory === '') &&
          (dataCheck.ar_title.search(this.searchKeyWord) !== -1)
        ) {
          return dataCheck
        }
      })
      // 增加一个根据页码筛选
      if (type === 'count') return articleList
      const startNumber = (this.paginationCurrent - 1) * this.paginationSize + 1
      const endNumber = this.paginationCurrent * this.paginationSize
      articleList = articleList.slice(startNumber - 1, endNumber)
      return articleList
    },
    // 分页在改变页数的时候，获取当前页数
    changePagination (page) {
      this.paginationCurrent = page
    }
  },
  mounted () {
    // 由于生命周期问题，将读取列表的工作稍微推迟一点
    this.$nextTick(function () {
      // 从后台把标签及其相关的数据拿出来
      this.getTagsInfo()
      this.getCategoryInfo()
      this.getArticleInfo()
    })
  }
}
</script>

<style lang="less" scoped>
/*标签选择栏的样式*/
.TagBox{
  display: inline-block;
  margin: 5px 5px;
  width: 120px;
  cursor: pointer;
}
.TagCount{
  display: inline-block;
  background: #73c9e5;
  color: white;
  width: 20px;
  text-align: center;
  border-radius: 2px;
  font-size: 12px;
}
//让被点击的标签给个边框
.TagBlue{
  border: 1px solid blue;
}
//文章列表的样式
.ArticleCard{
  margin: 10px auto 20px auto;
  cursor: pointer;
  width: 900px;
  .TitleText{
    font-size: 18px;
    font-weight: bold;
  }
  .CategoryText{
    border: 1px solid #bdc7cc;
    border-radius: 8px;
    padding: 0 10px;
    font-size: 16px;
    margin-right: 20px;
    margin-left: 10px;
  }
  .tagsBox{
    margin: 20px 5px 0 5px;
    //画个小三角
    .tagsTriangle{
      display: inline-block;
      transform: translate(0,5px);
      width: 0;
      height: 0;
      border-top: 10px solid transparent;
      border-bottom: 10px solid transparent;
      border-right: 10px solid #58555A;
    }
    .tagsText{
      font-size: 8px;
      padding: 2px 4px 2px 2px;
      display: inline-block;
      color: white;
      background-color: #58555A;
    }
  }
  .showtimeBox{
    margin-top: 25px;
    float: right;
    font-size: 14px;
  }
}
//让背景在悬停时有阴影
.ArticleCard:hover{
  background-color: #F5F7FA;
}
//搜索框
.searchBox{
  position: absolute;
  top: 20px;
  left: 33%;
  width: 40%;
  text-align: center;
}
</style>
