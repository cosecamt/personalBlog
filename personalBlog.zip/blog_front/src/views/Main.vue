<template>
  <el-container>
    <img class="webLogo" src="../assets/picture/Logo.png" alt="">
    <!--背景图-->
    <img class="mainBackground" src="../assets/picture/main_backgroud.jpg" alt="">
    <!--头部-->
    <el-header height="100px" style="padding: 0;">
      <!--头部背景图-->
      <div class="headerBackgroud">
      </div>
    </el-header>
    <el-container>
      <!--个人信息部分-->
      <el-aside width="20%">
        <el-card class="leftcard" shadow="never">
          <div style="display: inline-block">
            <el-avatar class="face" :src="require('../assets/picture/face.png')"></el-avatar>
          </div>
          <div class="myNote">
            <span>我叫景风时雨</span><br>
            <span>我最喜欢的宝可梦是伊布</span><br>
            <span>最近在玩《怪物猎人Rise》</span>
          </div>
          <el-divider></el-divider>
          <span>欢迎来到我的爆破场</span><br>
          <span>正在想好听好记好输入的域名</span>
        </el-card>
      </el-aside>
      <!--文章列表，占位符-->
      <el-main width="60%"><router-view></router-view></el-main>
      <el-aside width="20%">
        <!--公告卡片-->
        <el-card class="rightCard" shadow="never">
          <span style="font-weight: 700;font-size: 20px">公告</span>
          <el-divider></el-divider>
          正在考虑更换香港的服务器。。。。<br>
          感觉域名备案好麻烦。。。。<br>
          域名打算叫：breeze-pluvial
        </el-card>
      </el-aside>
    </el-container>
  </el-container>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
//主背景
.mainBackground{
  position: fixed;
  top: 0;
  height: 100%;
  width: 100%;
  z-index: -10;
}
//头部背景
.headerBackgroud{
  background-image: url(../assets/picture/main_header2.jpg);
  height: 100%;
  width: 100%;
  opacity: 0.4;
}
.webLogo{
  position: absolute;
  top: 10px;
  left: 150px;
}
//公告卡片
.rightCard{
  width: 350px;
  margin: 20px 10px 0 0;
}
//个人信息卡片
.leftcard{
  background-color: #F9F9F9;
  width: 350px;
  margin: 20px 10px 0 10px;
  .face{
    margin-left: 10px;
    width: 100px;
    height: 100px;
    text-align: center;
  }
  .myNote{
    position: relative;
    top: -20px;
    left: 15px;
    display: inline-block;
  }
}
</style>
