<template>
  <div class="WriterBackgroud">
    <el-container>
      <el-main>
        <!--标题输入框-->
        <div style="margin-bottom: 30px;">
          文章标题：
          <el-input placeholder="请输入标题" v-model="articleData.ar_title" style="width: 800px;"></el-input>
        </div>
          <!--文章内容框-->
        <div>
          <span>内容编辑：</span>
          <!--富文本编辑器-->
          <quill-editor v-model="articleData.ar_content" class="QEditor" :options="editorOption" ></quill-editor>
          <!--发布按钮-->
          <el-button type="success" @click="modifyArticle" style="display: block; margin: 50px 0 0 80px">发布</el-button>
        </div>
      </el-main>
      <el-aside width="900px">
        <!--时间输入框-->
        <div style="margin-bottom: 30px;margin-top: 20px;">
          录入时间：
          <el-date-picker value-format="yyyy-MM-dd" v-model="articleData.ar_showtime" type="date" placeholder="选择日期"></el-date-picker>
        </div>
        <!--作者输入框-->
        <div style="margin-bottom: 30px;">
          作者姓名：
          <el-input placeholder="请输入作者名" v-model="articleData.ar_author" style="width: 220px;"></el-input>
        </div>
        <!--文章种类-->
        文章种类：
        <el-select v-model="articleData.ar_category" placeholder="请选择">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>
        <br>
        <!--文章标签-->
        <div style="margin-top: 30px">
          <el-button @click="addNewTags" style="padding: 8px;margin-right: 10px;">添加新标签</el-button>
          <el-input placeholder="请输入标签名" v-model="newtags" style="width: 160px;"></el-input>
        </div>
        <el-card class="box-card TagCard">
          <div slot="header" class="clearfix">
            <span>选择你的Tags</span>
            <el-button style="float: right; padding: 3px 0" type="text" @click="cleanTags">清空</el-button>
          </div>
          <el-checkbox-group v-model="selectTags" size="mini">
            <el-checkbox v-for="tag in allTags" v-bind:key="tag.ta_id" :label="tag.ta_words" border></el-checkbox>
          </el-checkbox-group>
        </el-card>
      </el-aside>
    </el-container>
  </div>
</template>

<script>
export default {
  data () {
    return {
      // 待发送的文章内容
      articleData: {
        ar_title: '',
        ar_content: '',
        ar_showtime: '',
        ar_author: '景风时雨',
        ar_category: '',
        ar_tags: ''
      },
      // 富文本编辑器工具栏设置
      editorOption: {
        modules: {
          toolbar: [
            ['bold', 'strike', 'code-block', 'image', 'video', 'clean'],
            [{ header: [1, 2, 3, 4, 5, 6, false] }],
            [{ size: ['small', false, 'large', 'huge'] }],
            [{ color: [] }, { background: [] }, { align: [] }]
          ]
        }
      },
      // 文章类型的备选项
      options: [
        { value: '解决方法', label: '解决方法' },
        { value: '归纳总结', label: '归纳总结' },
        { value: '技术前瞻', label: '技术前瞻' },
        { value: '作品展示', label: '作品展示' },
        { value: '好奇求证', label: '好奇求证' }
      ],
      // 输入新标签名
      newtags: '',
      // 所有的Tag
      allTags: [],
      // 选定的Tag
      selectTags: []
    }
  },
  methods: {
    // 增加新的文章标签
    async addNewTags () {
      // 输入框为空的话不可以
      if (this.newtags === '' || this.newtags[0] === ' ') {
        return
      }
      const { data: res } = await this.$axios.post('addNewTags', { tagName: this.newtags })
      console.log(res)
      // 增加之后清空输入框，刷新数据
      this.newtags = ''
      await this.getTags()
    },
    // 从后台把标签全部拿出来
    async getTags () {
      const { data: res } = await this.$axios.post('getTags')
      this.allTags = res
    },
    // 清空已选标签
    cleanTags () {
      this.selectTags = []
    },
    // 修改完了就可以发回去了
    async modifyArticle () {
      // 检查有没有没填写的
      if (this.articleData.ar_category === '' ||
          this.articleData.ar_author === '' ||
          this.articleData.ar_content === '' ||
          this.articleData.ar_showtime === '' ||
          this.articleData.ar_title === '' ||
          this.selectTags === []) {
        alert('存在未填写的部分')
        return
      }
      // 拼接标签字符串
      this.articleData.ar_tags = ''
      for (let i = 0; i < this.selectTags.length; i++) {
        this.articleData.ar_tags = this.articleData.ar_tags + this.selectTags[i] + ';'
      }
      // 发去后台
      this.articleData.ar_id = this.$route.params.ar_id
      const { data: res } = await this.$axios.post('modifyArticle', this.articleData)
      console.log(res)
      // 完成后退回到后台列表
      await this.$router.push('/backMain')
    },
    // 从后台将待修改文章的信息提取出来并填充到数据中去
    async searchThisArticle () {
      const { data: res } = await this.$axios.post('searchArticleInfo', { data: this.$route.params.ar_id })
      this.articleData = res
      // 但是tag相关的信息还得拼接
      this.selectTags = res.ar_tags.split(';')
      // 如果按分号分，最后肯定多出来一个空的，弹栈吧
      this.selectTags.pop()
    }
  },
  mounted () {
    // 由于生命周期问题，将读取列表的工作稍微推迟一点
    this.$nextTick(function () {
      // 从后台把标签全部拿出来
      this.getTags()
      this.searchThisArticle()
    })
  }
}
</script>

<style lang="less" scoped>
.WriterBackgroud{
  z-index: -10;
  position: fixed;
  background-image: url(../../assets/picture/writerBackground.jpg);
  height: 100%;
  width: 100%;
  opacity: 0.8;
  background-size: cover;
}
.QEditor{
  vertical-align: text-top;
  display: inline-block;
  width: 800px;
  background-color: white;
}
//选择TAG的卡片
.TagCard{
  margin-top: 30px;
  width: 800px;
  height: 530px;
}
</style>
