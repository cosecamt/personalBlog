<template>
  <div>
    <!--新增文章按钮-->
    <el-button @click="goToNewArticle">新增</el-button>
    <!--文章列表-->
    <div v-for="article in articleList" :key="article.ar_id" @click="modifyThisArticle(article.ar_id)">
      <el-link>{{article.ar_id + "：" + article.ar_title + "_" + article.ar_showtime}}</el-link><br>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      articleList: [
        {
          ar_id: '',
          ar_title: '',
          ar_author: '',
          ar_tags: '',
          ar_category: '',
          ar_showtime: ''
        }
      ]
    }
  },
  methods: {
    // 去除所有文章的信息
    async getArticleInfo () {
      const { data: res } = await this.$axios.post('getArticleInfo')
      this.articleList = res
    },
    // 发布新文章
    goToNewArticle () {
      this.$router.push('/backNewArticle')
    },
    // 修改这篇文章
    modifyThisArticle (arid) {
      this.$router.push('/backModifyArticle/' + arid)
    }
  },
  mounted () {
    // 由于生命周期问题，将读取列表的工作稍微推迟一点
    this.$nextTick(function () {
      // 从后台把文章信息拿出来，但是文章内容不要内容
      this.getArticleInfo()
    })
  }

}
</script>

<style lang="less" scoped>

</style>
