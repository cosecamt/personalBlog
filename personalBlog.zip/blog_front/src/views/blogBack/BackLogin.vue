<template>
  <div>
    账号：
    <el-input class="inputBox" v-model="loginInfo.po_id"></el-input>
    <br>
    密码：
    <el-input class="inputBox" v-model="loginInfo.po_psw" show-password></el-input>
    <br>
    <el-button @click="loginBack" class="buttonBox" type="success">登录</el-button>
    <el-button @click="cleanInfo" class="buttonBox" type="info">清空</el-button>
  </div>
</template>

<script>
export default {
  data () {
    return {
      loginInfo: {
        po_id: '',
        po_psw: ''
      }
    }
  },
  methods: {
    cleanInfo () {
      this.loginInfo.po_id = ''
      this.loginInfo.po_psw = ''
    },
    async loginBack () {
      const { data: res } = await this.$axios.post('loginBack', this.loginInfo)
      if (res !== '登陆成功') {
        alert(res)
        return
      }
      // 登录成功后，添加token并且跳转页面到后台
      window.sessionStorage.setItem('token', 'testToken')
      await this.$router.push('/backMain')
    }
  }
}
</script>

<style lang="less" scoped>
.inputBox{
  margin-top: 20px;
  width: 300px;
}
.buttonBox{
  margin: 20px 0 0 40px;
}
</style>
