<?php

namespace app\model;

use think\model;

class Article extends Model{
    protected $table = 'mg2_article';
}