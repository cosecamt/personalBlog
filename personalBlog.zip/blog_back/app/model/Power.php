<?php

namespace app\model;

use think\model;

class Power extends Model{
    protected $table = 'mg2_power';
}