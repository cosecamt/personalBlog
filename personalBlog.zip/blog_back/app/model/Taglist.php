<?php

namespace app\model;

use think\model;

class Taglist extends Model{
    protected $table = 'mg2_taglist';
}