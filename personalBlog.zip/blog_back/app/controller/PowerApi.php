<?php

namespace app\controller;

use app\model\Power;
use think\Request;

class PowerApi{
    public function loginBack(Request $request){
        $tablePower = new Power;
        $powerSearch = $tablePower->where('po_id','=',$request->param('po_id'))->select();
        //首先看看账号存不存在
        if(count($powerSearch) == 0){
            return json("账号不存在");
        }
        //再看看密码对不对
        if($request->param('po_psw') == $powerSearch[0]['po_psw']){
            return json("登陆成功");
        }
        return json("密码不正确");
    }
}