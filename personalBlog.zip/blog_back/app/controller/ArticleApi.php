<?php

namespace app\controller;

use think\Model;
use think\Request;
use app\model\Article;

class ArticleApi{
    //发送文章信息到后台
    public function sendArticle(Request $request){
        $tableArticle = new Article;
        //然后拟定文章的编号
        $ar_id = "";
        $allId = $tableArticle->order('ar_id','desc')->select();
        if(count($allId) == 0){
            $ar_id = "文-0001";
        }else{
            $maxId = $allId[0]['ar_id'];
            $laterNumber = explode('-',$maxId)[1];
            $ar_id = "文-".sprintf("%04d",$laterNumber + 1);
        }
        //填入模型保存
        $tableArticle->ar_id = $ar_id;
        $tableArticle->ar_title = $request->param('ar_title');
        $tableArticle->ar_content = $request->param('ar_content');
        $tableArticle->ar_author = $request->param('ar_author');
        $tableArticle->ar_tags = $request->param('ar_tags');
        $tableArticle->ar_category = $request->param('ar_category');
        $tableArticle->ar_showtime = $request->param('ar_showtime');
        $tableArticle->save();
        return json("success");
    }

    //从后台获取文章列表，但是不包括内容
    public function getArticleInfo(){
        $tableArticle = new Article;
        //把信息取出来，但是不要内容，顺序按日期
        $articleInfo = $tableArticle->field('ar_id,ar_title,ar_author,ar_tags,ar_category,ar_showtime')
                                    ->order('ar_showtime','desc')->select();
        return json($articleInfo);
    }

    //从后台获取待修改的文章的信息，好像也可以用来读取文章内容嘛
    public function searchArticleInfo(Request $request){
        $tableArticle = new Article;
        //先把编号取出来
        $ar_id = $request->param('data');
        //查找该文章的所有信息
        $articleInfo = $tableArticle->where('ar_id','=',$ar_id)->select();
        return json($articleInfo[0]);
    }

    //修改文章
    public function modifyArticle(Request $request){
        $tableArticle = new Article;
        $thisArticle = $tableArticle->where('ar_id','=',$request->param('ar_id'))->find();
        $thisArticle->ar_title = $request->param('ar_title');
        $thisArticle->ar_content = $request->param('ar_content');
        $thisArticle->ar_author = $request->param('ar_author');
        $thisArticle->ar_tags = $request->param('ar_tags');
        $thisArticle->ar_category = $request->param('ar_category');
        $thisArticle->ar_showtime = $request->param('ar_showtime');
        $thisArticle->save();
        //尴尬，又要全都存一遍，不过这次是改
        return json("success");
    }

    // 获取单篇文章信息，这次需要完整的信息，包括文章内容
    public function getCompleteArticle(Request $request){
        $tableArticle = new Article;
        $articleInfo = $tableArticle->where('ar_id','=',$request->param('ar_id'))->find();
        return json($articleInfo);
    }
}
