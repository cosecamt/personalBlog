<?php

namespace app\controller;

use think\Model;
use think\Request;
use app\model\Taglist;
use app\model\Article;

class TaglistApi{
    //添加新的文章标签
    public function addNewTags(Request $request){
        $TableTaglist = new Taglist;
        $tagName = $request->param('tagName');
        //先查查这个tag存在否，如果存在直接失败
        $existTag = $TableTaglist->where('ta_words','=',$tagName)->select();
        if(count($existTag) != 0){
            return json('failure');
        }
        //如果不重复，那么需要确定编号，先把所有的查出来
        $maxTag = 0;
        $allTag = $TableTaglist->order('ta_id','desc')->select();
        //如果没有的话，直接设为1
        if(count($allTag) == 0){
            $maxTag = 1;
        }else{
        //如果有的话，那么就是最大值+1
        $maxTag = $allTag[0]['ta_id'] + 1;
        }
        //添加该数据
        $TableTaglist->ta_words = $tagName;
        $TableTaglist->ta_id = $maxTag;
        $TableTaglist->save();
        return json($tagName);
    }

    //获取所有标签
    public function getTags(){
        $TableTaglist = new Taglist;
        $allTags = $TableTaglist->order('ta_id')->select();
        return json($allTags);
    }

    //获取所有标签，还要相应的数量信息
    public function getTagsInfo(){
        $TableTaglist = new Taglist;
        $TableArticle = new Article;
        $allTags = $TableTaglist->order('ta_id')->select();
        for($i = 0; $i < count($allTags); $i++){
            //查询条件有点复杂，单独写吧
            $condition = "%".$allTags[$i]['ta_words']."%";
            $thisTagUesd = $TableArticle->where('ar_tags','like',$condition)->select();
            $allTags[$i]['tagCount'] = count($thisTagUesd);
        }
        return json($allTags);
    }

    // 找到所有的文章类型，并且把数据拿出来
    public function getCategoryInfo(){
        $TableArticle = new Article;
        //先用限制找法把不重复的类型名找出来
        $allCategory = $TableArticle->distinct(true)->field('ar_category')->select();
        //查找数量和标签那部分是一样的
        for($i = 0; $i < count($allCategory); $i++){
            $thisUesd = $TableArticle->where('ar_category','=',$allCategory[$i]['ar_category'])->select();
            $allCategory[$i]['categoryCount'] = count($thisUesd);
        }
        return json($allCategory);
    }
}