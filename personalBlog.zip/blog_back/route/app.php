<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
use think\facade\Route;

Route::get('think', function () {
    return 'hello,ThinkPHP6!';
});

Route::get('hello/:name', 'index/hello');


//---------- 此处为后台文章相关的Api ----------
//发送文章信息到后台
Route::rule('sendArticle', 'ArticleApi/sendArticle');

//从后台获取文章列表，但是不包括内容
Route::rule('getArticleInfo', 'ArticleApi/getArticleInfo');

//从后台获取待修改的文章的信息，好像也可以用来读取文章内容嘛
Route::rule('searchArticleInfo', 'ArticleApi/searchArticleInfo');

// 获取单篇文章信息，这次需要完整的信息，包括文章内容
Route::rule('getCompleteArticle', 'ArticleApi/getCompleteArticle');

//修改文章
Route::rule('modifyArticle', 'ArticleApi/modifyArticle');

//---------- 此处为标签列表相关的Api ----------
//添加新的文章标签
Route::rule('addNewTags','TaglistApi/addNewTags');

//获取所有标签
Route::rule('getTags','TaglistApi/getTags');

//获取所有标签，还要相应的数量信息
Route::rule('getTagsInfo','TaglistApi/getTagsInfo');

// 找到所有的文章类型，并且把数据拿出来
Route::rule('getCategoryInfo','TaglistApi/getCategoryInfo');

//---------- 此处为权限相关的Api ----------
Route::rule('loginBack','PowerApi/loginBack');
