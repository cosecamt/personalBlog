﻿# Host: localhost  (Version: 5.5.53)
# Date: 2021-05-24 20:26:36
# Generator: MySQL-Front 5.3  (Build 4.234)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "mg2_article"
#

DROP TABLE IF EXISTS `mg2_article`;
CREATE TABLE `mg2_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ar_id` varchar(32) NOT NULL DEFAULT '' COMMENT '编号',
  `ar_title` varchar(32) NOT NULL DEFAULT '' COMMENT '标题',
  `ar_content` text NOT NULL COMMENT '内容',
  `ar_author` varchar(32) NOT NULL DEFAULT '' COMMENT '作者',
  `ar_tags` varchar(32) NOT NULL DEFAULT '' COMMENT '标签',
  `ar_category` varchar(32) NOT NULL DEFAULT '' COMMENT '类别',
  `ar_showtime` varchar(32) NOT NULL DEFAULT '' COMMENT '展示出来的时间',
  `ar_cratetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='文章管理';

#
# Data for table "mg2_article"
#

/*!40000 ALTER TABLE `mg2_article` DISABLE KEYS */;
/*!40000 ALTER TABLE `mg2_article` ENABLE KEYS */;

#
# Structure for table "mg2_power"
#

DROP TABLE IF EXISTS `mg2_power`;
CREATE TABLE `mg2_power` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `po_id` varchar(32) NOT NULL DEFAULT '' COMMENT '账号',
  `po_psw` varchar(32) NOT NULL DEFAULT '' COMMENT '密码',
  `po_level` varchar(32) NOT NULL DEFAULT '' COMMENT '权限',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='权限管理';

#
# Data for table "mg2_power"
#

/*!40000 ALTER TABLE `mg2_power` DISABLE KEYS */;
INSERT INTO `mg2_power` VALUES (1,'admin','admin','管理员');
/*!40000 ALTER TABLE `mg2_power` ENABLE KEYS */;

#
# Structure for table "mg2_taglist"
#

DROP TABLE IF EXISTS `mg2_taglist`;
CREATE TABLE `mg2_taglist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ta_id` int(11) NOT NULL DEFAULT '0' COMMENT '显示的顺序',
  `ta_words` varchar(32) NOT NULL DEFAULT '' COMMENT '标签内容',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='标签列表';

#
# Data for table "mg2_taglist"
#

/*!40000 ALTER TABLE `mg2_taglist` DISABLE KEYS */;
INSERT INTO `mg2_taglist` VALUES (1,1,'Python'),(2,2,'Php'),(3,3,'Vue'),(4,4,'C#'),(5,5,'JavaScript');
/*!40000 ALTER TABLE `mg2_taglist` ENABLE KEYS */;
